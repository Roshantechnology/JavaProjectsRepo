package com.ineuron;

//Base Class
class Parent{

	// Constructor for class Programming
	public Parent()
	{
		System.out.println("Parent call");
	}
}

//Child Class inherit the Base
//Class
class Child extends Parent {

	// Constructor for class Child
	public Child() { 
		//invoking constructor of Parent by using super() here which is called by default
		System.out.println("Child call"); }
}

//Main Class
public class Main {

	public static void main(String[] args)
	{
		// Creating obj for
		// Child class 
		Child obj = new Child();
	}
}

package in.ineuron.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Enumeration;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/Disp")
public class DisplayServlet1 extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		
		String uname = request.getParameter("uname");
		HttpSession session = request.getSession();
		session.setAttribute("User's Name", uname);
		PrintWriter out = response.getWriter();
		out.println("<html><head><title>output</title></head>");
		out.println("<body bgcolor='lightyellow'>");
		out.println("<h1 style='color:Red; text-align:center;'>Registration Details</h1>");
		out.println("<center>");
		out.println("<table border='5'>");
		
		out.println("<tr><th>NAME</th><th>VALUE</th></tr>");
		Enumeration<String> attributeNames = session.getAttributeNames();
		while(attributeNames.hasMoreElements()) {
			String AttributeName = attributeNames.nextElement();
			Object attributeValue = session.getAttribute(AttributeName);
			out.println("<tr><td>"+AttributeName+"</td><td>"+attributeValue+"</td></tr>");
		}
		out.println("</table>");
		out.println("</center>");
		out.println("</body>");
		out.println("</html>");
		
		out.close();		
	}

}

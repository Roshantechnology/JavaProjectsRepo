package in.ineuron.main;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class BatchUpdateUsingPreparedStatement {
    private static final String DB_URL = "jdbc:postgresql://localhost:5432/mydatabase";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "Roshan@9182";

    public static void main(String[] args) {
        String inputFile = "input.txt";

        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            connection.setAutoCommit(false); // Enable manual commit

            // Create prepared statement with the batch update query
            String query = "INSERT INTO employee (ename, eage) VALUES (?, ?)";
            PreparedStatement statement = connection.prepareStatement(query);

            // Read the input file
            BufferedReader reader = new BufferedReader(new FileReader(inputFile));
            String line;
            while ((line = reader.readLine()) != null) {
                String[] data = line.split(","); // Assuming comma-separated values
                String value1 = data[0];
                String value2 = data[1];

                // Set parameters for the prepared statement
                statement.setString(1, value1);
                statement.setString(2, value2);

                // Add the current statement to the batch
                statement.addBatch();
            }

            // Execute the batch update
            int[] updateCounts = statement.executeBatch();

            // Commit the changes
            connection.commit();

            // Print the update counts
            for (int count : updateCounts) {
                System.out.println("Rows updated: " + count);
            }

            // Close resources
            statement.close();
            reader.close();
        } catch (IOException | SQLException e) {
            e.printStackTrace();
        }
    }
}

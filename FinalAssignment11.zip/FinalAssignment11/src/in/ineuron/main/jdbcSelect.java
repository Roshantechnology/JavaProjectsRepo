package in.ineuron.main;


import java.sql.Connection;

import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class jdbcSelect {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		Connection connection=null;
		Statement statement=null;
		
		Class.forName("com.mysql.cj.jdbc.Driver");
		System.out.println("Driver object creted successfully");
		String url="jdbc:mysql://localhost:3306/octbatch";
		String user="root";
		String pass="Roshan@9182";
		connection= DriverManager.getConnection(url,user,pass);
		System.out.println("connection object creted successfully");
		System.out.println("connection object name:="+connection.getClass().getName());
		
		statement=connection.createStatement();
		System.out.println("Statement object creted successfully");
		System.out.println("Statement object name:="+statement.getClass().getName());
		System.out.println("===================================================");
		String sqlSelectQuery = "select sid,sname,sage,saddress from student";
		ResultSet resultSet = statement.executeQuery(sqlSelectQuery);
		System.out.println("RESULTSET object created...");
		System.out.println("SID\tSNAME\tSAGE\tSADDRESS");
		while (resultSet.next()) {
		int sid = resultSet.getInt("sid");
		String sname = resultSet.getString("sname");

		int sage = resultSet.getInt("sage");
		String saddress = resultSet.getString("saddress");
		System.out.println(sid + "\t" + sname + "\t" + sage + "\t" +

		saddress);
		}
		resultSet.close();
		statement.close();
		connection.close();
		System.out.println("Closing the resources...");
		}

}

//Output
//Driver object creted successfully
//connection object creted successfully
//connection object name:=com.mysql.cj.jdbc.ConnectionImpl
//Statement object creted successfully
//Statement object name:=com.mysql.cj.jdbc.StatementImpl
//===================================================
//RESULTSET object created...
//SID	SNAME	SAGE	SADDRESS
//1	Roshan	24	Nagpur
//2	Bhushan	25	Pune
//Closing the resources...


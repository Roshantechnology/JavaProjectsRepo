package in.ineuron.service;

import in.ineuron.dto.Student;

public interface IStudentService {

	// operations to be implemented
	public String updateById(Student student);

	public Student findById(Integer sid);


}

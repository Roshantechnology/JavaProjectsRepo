package com.ineuron;

public class Runnable2 implements Runnable {
	   public void run(){
		   System.out.println(" ");
	        for(int i=0;i<11;i+=2) {
	            System.out.print(" "+i);
	        }
	        
	        System.out.println(" ");
	    }
	}


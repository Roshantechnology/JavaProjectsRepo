package in.ineuron.service;

import in.ineuron.bo.CoronaVaccine;

public interface ICoronaVaccineMgmtService {

	public String registerVacine(CoronaVaccine vaccine);
}

package in.ineuron;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;

import in.ineuron.bo.CoronaVaccine;
import in.ineuron.service.ICoronaVaccineMgmtService;

@SpringBootApplication
public class SpringBootDataJpaInsertionApplication {

	public static void main(String[] args) {
		
		ApplicationContext factory = SpringApplication.run(SpringBootDataJpaInsertionApplication.class, args);
		
		ICoronaVaccineMgmtService service = factory.getBean(ICoronaVaccineMgmtService.class);
		CoronaVaccine vaccine = new CoronaVaccine(null,"Covaxin","Bharat-Biotech","Ind",236.5,3);
		System.out.println(service.registerVacine(vaccine));
		((ConfigurableApplicationContext) factory).close();
	}

}

package in.ineuron.service;

import in.ineuron.dto.Blog;

public interface IBlogService {
	
	// operations to be implemented
	public String addStudent(Blog blog);

	public Blog readBlog(Integer bid);


}

package in.ineuron.service;

import in.ineuron.daofactory.BlogDaoFactory;
import in.ineuron.dto.Blog;
import in.ineuron.dao.IBlogDao;

//service layer logic
public class BlogServiceImpl implements IBlogService {

	private IBlogDao stdDao;

	@Override
	public String addStudent(Blog blog) {
		stdDao = BlogDaoFactory.getBlogDao();
		return stdDao.createBlog(blog);
		//return stdDao.addStudent(blog);
	}

//	@Override
//	public Blog searchStudent(Integer sid) {
//		stdDao = StudentDaoFactory.getStudentDao();
//		return stdDao.searchStudent(sid);
//	}

	@Override
	public Blog readBlog(Integer bid) {
		stdDao = BlogDaoFactory.getBlogDao();
		return stdDao.readBlog(bid);
	}

}

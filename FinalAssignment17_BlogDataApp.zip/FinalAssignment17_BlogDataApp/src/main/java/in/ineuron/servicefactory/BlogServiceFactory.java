package in.ineuron.servicefactory;

import in.ineuron.service.IBlogService;

import in.ineuron.service.BlogServiceImpl;


//Abstraction logic of implementation
public class BlogServiceFactory {

	//make constuctor private to avoid object creation
	private BlogServiceFactory() {

	}

	private static IBlogService blogService = null;

	public static IBlogService getBlogService() {
		
		//singleton pattern code
		if (blogService == null) {
			blogService = new BlogServiceImpl();
		}
		return blogService;
	}

}

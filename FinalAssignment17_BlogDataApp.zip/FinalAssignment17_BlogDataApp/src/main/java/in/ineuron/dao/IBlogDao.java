package in.ineuron.dao;

import in.ineuron.dto.Blog;

public interface IBlogDao {
	
	// operations to be implemented
	public String createBlog(Blog blog);

	public Blog readBlog(Integer bid);


}

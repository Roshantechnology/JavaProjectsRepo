package in.ineuron.dao;

import java.io.IOException;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import in.ineuron.dto.Blog;
import in.ineuron.util.JdbcUtil;

//Persistence logic using JDBC API
public class BlogDaoImpl implements IBlogDao {

	Connection connection = null;
	PreparedStatement pstmt = null;
	ResultSet resultSet=null;

	@Override
	public String createBlog(Blog blog) {
		String sqlIsertQuery="insert into blogdata(`BTitle`,`BContent`,`BDescription`)values(?,?,?)";
		
		try {
			connection=JdbcUtil.getJdbcConnection();
			if(connection!=null) {
				 pstmt = connection.prepareStatement(sqlIsertQuery);
			}
			if(pstmt!=null) {
				pstmt.setString(1, blog.getBtitle());
				pstmt.setString(2, blog.getBcontent());
				pstmt.setString(3, blog.getBdescription());
				
				int rowAffected = pstmt.executeUpdate();
				if(rowAffected==1) {
					return "success";
				}
			}
		} catch (IOException e) {
			
			e.printStackTrace();
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		return "failure";
	}
	
	
	@Override
	public Blog readBlog(Integer bid) {
		String sqlSelectQuery = "select bid,btitle,bcontent,bdescription from blogdata where bid = ?";
		Blog blog = null;

		try {
			connection = JdbcUtil.getJdbcConnection();

			if (connection != null)
				pstmt = connection.prepareStatement(sqlSelectQuery);

			if (pstmt != null)
				pstmt.setInt(1, bid);

			if (pstmt != null) {
				resultSet = pstmt.executeQuery();
			}

			if (resultSet != null) {

				if (resultSet.next()) {
					blog = new Blog();

					// copy resultSet data to student object
					blog.setBid(resultSet.getInt(1));
					blog.setBtitle(resultSet.getString(2));
					blog.setBcontent(resultSet.getString(3));
					blog.setBdescription(resultSet.getString(4));

					return blog;
				}

			}

		} catch (SQLException | IOException e) {
			e.printStackTrace();
		}

		return blog;
	}

	
	}


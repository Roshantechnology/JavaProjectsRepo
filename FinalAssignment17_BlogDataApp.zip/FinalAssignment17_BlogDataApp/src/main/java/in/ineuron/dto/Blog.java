package in.ineuron.dto;

import java.io.Serializable;

public class Blog implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	private Integer bid;
	private String btitle;
	private String bcontent;
	private String bdescription;
	public Integer getBid() {
		return bid;
	}
	public void setBid(Integer bid) {
		this.bid = bid;
	}
	public String getBtitle() {
		return btitle;
	}
	public void setBtitle(String btitle) {
		this.btitle = btitle;
	}
	public String getBcontent() {
		return bcontent;
	}
	public void setBcontent(String bcontent) {
		this.bcontent = bcontent;
	}
	public String getBdescription() {
		return bdescription;
	}
	public void setBdescription(String bdescription) {
		this.bdescription = bdescription;
	}
	@Override
	public String toString() {
		return "Blog [bid=" + bid + ", btitle=" + btitle + ", bcontent=" + bcontent + ", bdescription=" + bdescription
				+ "]";
	}

	

	
	


}

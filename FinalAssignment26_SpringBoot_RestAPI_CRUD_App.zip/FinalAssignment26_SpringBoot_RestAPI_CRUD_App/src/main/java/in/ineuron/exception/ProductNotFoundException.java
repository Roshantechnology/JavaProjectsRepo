package in.ineuron.exception;


	public class ProductNotFoundException extends Exception {
		
		private static final long serialVersionUID = 1L;
		
		private Integer pid;
		
		public ProductNotFoundException(Integer pid) {
		        super(String.format("Product is not found with id : '%s'", pid));
		        }
		
}

package in.ineuron.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import in.ineuron.dao.ProductRepository;
import in.ineuron.exception.ProductNotFoundException;
import in.ineuron.model.Product;

@RestController
@RequestMapping("/api/controller")
public class ProductController {

	@Autowired
	ProductRepository prepo;
	

	// Get All Products
	    @GetMapping("/getproduct")
	    public List<Product> getAllProducts() {
	        return prepo.findAll();
	    }

	// Create a new Products
	    @PostMapping("/createproduct")
	    public Product createProduct(@RequestBody Product product) {
	        return prepo.save(product);
	    }

	// Get a Single Note
    @GetMapping("/getproduct/{id}")
	    public Product getProductById(@PathVariable(value = "id") Integer pid) throws ProductNotFoundException {
	        return prepo.findById(pid)
	                .orElseThrow(() -> new ProductNotFoundException(pid));
	    }


    // Update a product
     @PutMapping("/update/{id}")
     public Product updateProduct(@PathVariable(value = "id")Integer pid,
                           @RequestBody Product updateProduct) throws ProductNotFoundException {
    	 
    	 Product product = prepo.findById(pid)
                 .orElseThrow(() -> new ProductNotFoundException(pid));
    	 
    	 
    	 product.setPname(updateProduct.getPname());
    	 product.setPprice(updateProduct.getPprice());
    	 product.setPsize(updateProduct.getPsize());

    	 Product updateProduct1 = prepo.save(product);

    	 return updateProduct1;
     }

	// Delete a Note
	    @DeleteMapping("/deleteproduct/{id}")
	    public ResponseEntity<?> deleteProduct(@PathVariable(value = "id") Integer pid) throws ProductNotFoundException {
	    	Product product = prepo.findById(pid)
	                .orElseThrow(() -> new ProductNotFoundException(pid));

	    	prepo.delete(product);

	return ResponseEntity.ok().build();
	    }
	
}

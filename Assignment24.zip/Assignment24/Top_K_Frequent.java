package in.ineuron.Assignment24;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.PriorityQueue;

class Top_K_Frequent {
  public static List<String> topKFrequent(String[] words, int k) {
        HashMap<String, Integer> map = new HashMap();
        PriorityQueue<Map.Entry<String, Integer>> heap = new PriorityQueue<>(
            (a,b)->{
                if(a.getValue() != b.getValue())
                    return a.getValue().compareTo(b.getValue());
                return -a.getKey().compareTo(b.getKey());
            }
        );
        for(String word: words){
            map.merge(word, 1, Integer::sum);
        }
        for(Map.Entry<String, Integer> entry: map.entrySet()){
            heap.offer(entry);
            if(heap.size() > k)
                heap.poll();
        }
        List<String> ans = new ArrayList();
        while(heap.size() > 0)ans.add(heap.poll().getKey());
        Collections.reverse(ans);
        return ans;
    }
  public static void main(String[]args) {
	String []words= {"i","love","leetcode","i","love","coding"};
	int k=2;
	System.out.println(topKFrequent(words, k));

}
}
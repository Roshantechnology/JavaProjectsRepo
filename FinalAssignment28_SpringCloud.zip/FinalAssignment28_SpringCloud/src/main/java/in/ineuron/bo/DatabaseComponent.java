package in.ineuron.bo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class DatabaseComponent {
	 @Autowired
    private final DatabaseConfig databaseConfig;

   
    public DatabaseComponent(DatabaseConfig databaseConfig) {
        this.databaseConfig = databaseConfig;
    }

    // Use the database configuration
    public void connectToDatabase() {
        String url = databaseConfig.getUrl();
        String username = databaseConfig.getUsername();
        String password = databaseConfig.getPassword();

    }
}


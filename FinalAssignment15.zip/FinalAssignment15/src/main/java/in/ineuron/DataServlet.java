package in.ineuron;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/data")
public class DataServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    // MySQL database connection details
    private static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
    private static final String DB_URL = "jdbc:mysql://localhost:3306/octbatch";
    private static final String USER = "root";
    private static final String PASS = "Roshan@9182";

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html");

        PrintWriter out = response.getWriter();
        out.println("<html><body bgcolor=pink>");
        out.println("<center>");
        out.println("<h1> Employee Data </h1>");
        
        out.println("<table border=\"1\">");
        out.println("<tr><th>EmpId</th><th>EmpName</th><th>EAddress</th><th>ESalary</th></tr>");

        Connection conn = null;
        Statement stmt = null;
        ResultSet rs = null;

        try {
            // Register JDBC driver
            Class.forName(JDBC_DRIVER);

            // Open a connection to the database
            conn = DriverManager.getConnection(DB_URL, USER, PASS);

            // Execute SQL query
            stmt = conn.createStatement();
            String sql = "SELECT * FROM employees";
            rs = stmt.executeQuery(sql);

            // Process the result set
            while (rs.next()) {
            	 
                int n = rs.getInt("Eid");               
                String nm = rs.getString("Ename");  
                String addr = rs.getString("Eaddress");   
                int s = rs.getInt("Esalary");   
                out.println("<tr><td>" + n + "</td><td>" + nm + "</td><td>" + addr +"</td><td>" + s + "</td></tr>");   
            } 
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        } finally {
            // Close resources
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        out.println("</table>");
        out.println("</center>");
        out.println("</body></html>");
    }
}


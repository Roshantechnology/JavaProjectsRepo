package in.ineuron;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FinalAssignment23SpringMvcRegistrationApplication {

	public static void main(String[] args) {
		SpringApplication.run(FinalAssignment23SpringMvcRegistrationApplication.class, args);
	}

}

package in.ineuron.dto;

import org.springframework.data.jpa.repository.JpaRepository;

import in.ineuron.bo.User;

public interface UserRepository extends JpaRepository<User, Integer> {

	User findByUsername(String username);

}

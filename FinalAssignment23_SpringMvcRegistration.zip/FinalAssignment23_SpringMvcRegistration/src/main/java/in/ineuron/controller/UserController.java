package in.ineuron.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import in.ineuron.bo.User;
import in.ineuron.dto.UserRepository;

@Controller
public class UserController {

    @Autowired
    private UserRepository userrepo;

    @RequestMapping("/register")
    public String register(Model model) {
        User user = new User();
        return "welcome";
    }

    @RequestMapping(value = "/register", method = RequestMethod.POST)
    public String register(User user) {
        userrepo.save(user);
        System.out.println("successfull register");
        return "welcome";
    }

    @RequestMapping("/login")
    public String login(Model model) {
        User user = new User();
        model.addAttribute("user", user);
        return "welcome";
    }

    @RequestMapping(value = "/login", method = RequestMethod.POST)
    public String login(User user, Model model) {
        User foundUser = userrepo.findByUsername(user.getUsername());
        if (foundUser != null && foundUser.getPassword().equals(user.getPassword())) {
        	 model.addAttribute("msg", "successfull login");
        	System.out.println("successfull login ");
        	
        } else {
            model.addAttribute("msg", "Invalid username or password");
            System.out.println("fail login ");
            
        }
		return "welcome";
    }

}
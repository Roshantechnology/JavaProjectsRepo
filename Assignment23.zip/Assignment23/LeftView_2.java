package in.ineuron.Assignment23;
class LeftView_2 {
	int data;
	LeftView_2 left, right;

	public LeftView_2(int item)
	{
		data = item;
		left = right = null;
	}
}
class BinaryTree1 {
	LeftView_2 root;
	static int max_level = 0;
	void leftViewUtil(LeftView_2 node, int level)
	{
		if (node == null)
			return;
		if (max_level < level) {
			System.out.print(node.data + " ");
			max_level = level;
		}
		leftViewUtil(node.left, level + 1);
		leftViewUtil(node.right, level + 1);
	}
	void leftView()
	{
		max_level = 0;
		leftViewUtil(root, 1);
	}
	public static void main(String args[])
	{
		BinaryTree1 tree = new BinaryTree1();
		tree.root = new LeftView_2(10);
		tree.root.left = new LeftView_2(2);
		tree.root.right = new LeftView_2(3);
		tree.root.left.left = new LeftView_2(7);
		tree.root.left.right = new LeftView_2(8);
		tree.root.right.right = new LeftView_2(15);
		tree.root.right.left = new LeftView_2(12);
		tree.root.right.right.left = new LeftView_2(14);

		tree.leftView();
	}
}

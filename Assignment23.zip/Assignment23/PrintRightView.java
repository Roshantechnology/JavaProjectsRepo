package in.ineuron.Assignment23;
class PrintRightView {
	int data;
	PrintRightView left, right;

	PrintRightView(int item)
	{
		data = item;
		left = right = null;
	}
}
class Max_level {

	int max_level;
}

class BinaryTree {

	PrintRightView root;
	Max_level max = new Max_level();
	void rightViewUtil(PrintRightView node, int level,Max_level max_level)
	{
		if (node == null)
			return;
		if (max_level.max_level < level) {
			System.out.print(node.data + " ");
			max_level.max_level = level;
		}
		rightViewUtil(node.right, level + 1, max_level);
		rightViewUtil(node.left, level + 1, max_level);
	}

	void rightView() { rightView(root); }
	void rightView(PrintRightView node)
	{

		rightViewUtil(node, 1, max);
	}
	public static void main(String args[])
	{
		BinaryTree tree = new BinaryTree();
		tree.root = new PrintRightView(1);
		tree.root.left = new PrintRightView(2);
		tree.root.right = new PrintRightView(3);
		tree.root.left.left = new PrintRightView(4);
		tree.root.left.right = new PrintRightView(5);
		tree.root.right.left = new PrintRightView(6);
		tree.root.right.right = new PrintRightView(7);
		tree.root.right.left.right = new PrintRightView(8);

		tree.rightView();
	}
}

package in.ineuron.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import in.ineuron.dao.BookRepository;
import in.ineuron.model.Book;

	@RestController
	@RequestMapping("/test")
	public class BookController {
	
	@Autowired
	BookRepository bookRepository;


   // Create a new Note
    @PostMapping("/books")
    public Book createNote(@RequestBody Book book) {
        return bookRepository.save(book);
    }


}



import java.util.Random;
import java.util.Scanner;

public class BankOperationsImpl implements IBankOperations {
	
	
	static int AccountBal = 0;
	String accHolder[]= {"","","","",""};
	long accHolderMno;
	int accNo;
	public void ViewBalance() {
		System.out.println("**** YOUR ACCOUNT DETAILS ****");
		System.out.println("Account Holder Name :: "+accHolder[0]+" "+accHolder[1]);
		
		System.out.println("Account Holder Address :: "+accHolder[2]);
		System.out.println("Account Holder Contact :: "+accHolderMno);
		System.out.println("Account Number :: "+accNo);
		
		System.out.println("Your Current Balance is:"+AccountBal);
		System.out.println();
	}


	public void creditMoney() {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the amount which you want to Add");
		int CreditMon = sc.nextInt();
		AccountBal = AccountBal + CreditMon;
		System.out.println();
		System.out.println("Transaction Successful...");
	}


	public void withdrawMoney() {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the amount which you want to Withdraw");
		int withDrawAmount = sc.nextInt();
		
		AccountBal = AccountBal - withDrawAmount;
		if(AccountBal<500) {
			System.out.println();
			System.out.println("Sorry.. You Can't Withdraw Money.."+"\n"+"Because Entered Amount Is Exceeded From Minimum Balance Limit (Min Bal Limit = 500 Rs)");
			System.out.println();
			AccountBal = AccountBal + withDrawAmount;
		}else {
			System.out.println("Withdraw Operation Successful..");
			System.out.println("Balance is :: "+AccountBal+"\n");		}
		
	}


	public void openAccount() {
		Scanner sc=new Scanner(System.in);
		Scanner sc2=new Scanner(System.in);
		
		System.out.println("Enter Your First Name ::");
		accHolder[0] = sc.next();
		System.out.println("Enter Your Last Name ::");
		accHolder[1] = sc.next();
		System.out.println("Enter Your Address :: ");
		accHolder[2] = sc.next();
		System.out.println("Enter Your Adhar No ::");
		accHolder[3] = sc.next();
		System.out.println("Enter Your PAN No ::");
		accHolder[4] = sc.next();
		System.out.println("Enter Your Contact No ::");
		accHolderMno = sc2.nextLong();
		System.out.println("Enter Your Account Opening Amount (AMOUNT MUST BE >= 500 RS.) ::");
		int openAmnt = sc2.nextInt();
		Random rand = new Random();
	
		accNo = 3+(int)(Math.random() * 900000000 + 1);
		if(openAmnt<500) {
			System.out.println();
			System.out.println("You Can't Open Account With Less Than 500 Rupees");
			System.out.println();
			
		}else {
			AccountBal = AccountBal + openAmnt;
			System.out.println("Account Creates Successfuly...");
			System.out.println();
			
		}
		
	}

}

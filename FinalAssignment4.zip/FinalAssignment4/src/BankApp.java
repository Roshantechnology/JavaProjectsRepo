

import java.util.Scanner;

public class BankApp {

	public static void main(String[] args) {
		IBankOperations c = new BankOperationsImpl();
		boolean flag=true;
		Scanner sc=new Scanner(System.in);
		System.out.println("**********************************");
		System.out.println("	WELCOME TO INEURON BANK :)");
		System.out.println("**********************************");
		do {
			System.out.println("");
			System.out.println("1.Open Your Account ");
			System.out.println("2.Credit Money");
			System.out.println("3.Withdraw Money");
			System.out.println("4.View Balance");
			System.out.println("5.Exit");
			System.out.println("-----------------------------------");
			System.out.println("ENTER THE YOUR CHOICE");
			int choice = sc.nextInt();
			
			switch(choice) {
			case 1:c.openAccount();
				break;
			case 2:c.creditMoney();
				break;
			case 3:
				c.withdrawMoney();
				break;
			case 4:
				c.ViewBalance();
				break;
			case 5:System.out.println("Thank You.. For Choosing Our Bank Service..");
				System.exit(0);
				break;
				
			default:
				sc.close();
				System.exit(0);
			}
			System.out.println("Do You Want To Use Our Bank Service Again? [Yes(y/Y)/No] ::");
			Scanner sc2 = new Scanner(System.in);
			String ans=sc2.next();
			if("Yes".equals(ans)||"YES".equals(ans)||"yes".equals(ans)||"Y".equals(ans)||"y".equals(ans)) {
				flag=true;
			}else {
				flag=false;
				System.out.println("Thank You.. For Choosing Our Bank Service..");
			}
		}while(flag) ;
	}

}

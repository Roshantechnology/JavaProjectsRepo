

public interface IBankOperations {
	public void ViewBalance();
	public void creditMoney();
	public void withdrawMoney();
	public void openAccount();
}

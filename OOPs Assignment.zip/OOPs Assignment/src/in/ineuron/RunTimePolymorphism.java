package in.ineuron;
class Animal {
    void speak() {
        System.out.println("I am an animal");
    }
}

class Dog extends Animal {
    void speak() {
        System.out.println("Woof!");
    }
}

class Cat extends Animal {
    void speak() {
        System.out.println("Meow!");
    }
}

public class RunTimePolymorphism {
    public static void main(String[] args) {
        Animal animal = new Animal();
        animal.speak();

        Animal dog = new Dog();
        dog.speak();

        Animal cat = new Cat();
        cat.speak();
    }
}
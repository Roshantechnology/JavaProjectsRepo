package in.ineuron;

class parent{
  void Show() {
	  System.out.println("Parent calling");
  }
}
class child extends parent{
	@Override
	void Show() {
		  System.out.println("child calling");
	  }
}
public class Second {
  public static void main(String[] args) {
    parent p = new parent();
    p.Show();
	  child c = new child();
	  c.Show();
    
  }
}
package in.ineuron;

import java.util.Scanner;

public class BankApp {

	private String name;
	private String AccountNum;
	private long amount;
	public BankApp(String name,String Accountnum,long amount) {
		this.name=name;
		this.AccountNum=Accountnum;
		this.amount=amount;
		
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAccountNum() {
		return AccountNum;
	}
	public void setAccountNum(String accountNum) {
		AccountNum = accountNum;
	}
	public long getAmount() {
		return amount;
	}
	public void setAmount(long amount) {
		this.amount = amount;
	}
	public void deposit(long deposit) {
		amount+=deposit;
	}
	public void withdraw(long withdraw) {
		if(amount<withdraw) {
			System.out.println("Please Enter valid Amount Your");
		}
		else
			amount-=withdraw;
	}
	public static void main(String[] args) {
		System.out.println("*****************WELCOME TO INEURON BANK*******************");
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter your Name: ");
		String name = scan.nextLine();
		
		System.out.println("Enter Your Bank Account Number: ");
		String Accountnum=scan.nextLine();
		
		System.out.println("Enter The Amount You Want To Deposit: ");
		long amount = scan.nextLong();
		
		BankApp bankApp = new BankApp(name,Accountnum,amount);
		System.out.println("Account Holder Name: "+bankApp.getName());
		System.out.println("Bank Account Number: "+bankApp.getAccountNum());
		System.out.println("Current Bank Balance: "+bankApp.getAmount());
		System.out.println("1)press 1 for Amount deposit (2)press 2 for withdraw");
        int num = scan.nextInt();
        switch(num) {
        case 1:
        System.out.println("Enter amount to deposit: ");
        long deposit=scan.nextLong();
        bankApp.deposit(deposit);
        System.out.println("Your Current Balance"+bankApp.getAmount());
        break;
        case 2:
        	System.out.println("Enter amount to withdraw: ");
        	long withdraw=scan.nextLong();
        	bankApp.withdraw(withdraw);
        	System.out.println("Your Current Balance"+bankApp.getAmount());
        	 break;
        }
	}

}

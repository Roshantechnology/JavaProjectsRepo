package com.ineuron;

public class MyException extends Exception {
	
	private static final long serialVersionUID = 1L;

	public MyException(String str)
	 {
	  System.out.println(str);
	 }
}

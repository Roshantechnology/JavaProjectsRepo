package com.ineuron.abstractClass;

public abstract class sunstar {
	void basicIntro(){
		System.out.println("==============================================================");
	    System.out.println("INFORMATION ABOUT EMPLOYEE");		
	    System.out.println("==============================================================");
	    
	}
	  abstract void printInfo();
}

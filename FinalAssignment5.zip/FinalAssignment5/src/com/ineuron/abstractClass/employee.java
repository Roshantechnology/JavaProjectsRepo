package com.ineuron.abstractClass;

class employee extends sunstar {
   void printInfo()
   {
       String name = "suresh";
       int age = 21;
       float salary = 666.7F;

       System.out.println(name);
       System.out.println(age);
       System.out.println(salary);
   }
   


   public static void main(String args[])
   {
       sunstar s = new employee();
       s.basicIntro();
       s.printInfo();
   
}
}

package com.ineuron.interfacee;
interface Shape {
	 
    // Abstract method
    void draw();
    double area();
}
 
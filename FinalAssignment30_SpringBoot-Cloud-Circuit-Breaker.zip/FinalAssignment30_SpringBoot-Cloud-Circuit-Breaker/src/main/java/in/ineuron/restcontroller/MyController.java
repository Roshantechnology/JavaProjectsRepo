package in.ineuron.restcontroller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.circuitbreaker.CircuitBreakerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api")
public class MyController {

    @Autowired
    private CircuitBreakerFactory<?, ?> circuitBreakerFactory;

    @GetMapping("/hello")
    public ResponseEntity<String> hello() {
        // Use circuit breaker to wrap the remote API call
        String result = circuitBreakerFactory.create("hello").run(this::callRemoteAPI, throwable -> {
            // Handle circuit breaker open or other errors
            return "Fallback response";
        });

        return new ResponseEntity<>(result, HttpStatus.OK);
    }

    // Simulate a remote API call
    private String callRemoteAPI() {
        
        // Return the response
        return "Hello from remote API";
    }
}
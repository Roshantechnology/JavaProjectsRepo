package com.ineuron;

public class Triangles implements Shape {
	 private int base, height,thirdside;
	   
	   public Triangles(int thirdside, int base, int height) {
	      this.base = base;
	      this.height = height;
	      this.thirdside = thirdside;
	   }
	  
	   
	@Override
	public double area() {
		 return 0.5*base*height;
	}

	@Override
	public double perimeter() {
		return base + height + thirdside;
	}

}

package com.ineuron;

public class Main {

	public static void main(String[] args) {
		double length = 2.0;
		double breadth = 3.0;
		Rectangle r = new Rectangle(length, breadth);

		System.out.println("Rectangle - Area: " + r.area());
		System.out.println("Rectangle - perimeter: " + r.perimeter());

		// Circle area and parameter
		double radius = 2.0;
		Circles c = new Circles(radius);
		System.out.println("Circle - Area: " + c.area());
		System.out.println("Circle - perimeter: " + c.perimeter());
		
		int base = 3;
		int height = 6;
		int side3 = 5;
		Triangles t = new Triangles(side3, base, height);
		System.out.println("Triangle - Area: "+t.area());
		System.out.println("Triangle - perimeter:"+t.perimeter());
	}

}

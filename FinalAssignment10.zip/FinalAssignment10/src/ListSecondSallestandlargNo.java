import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

public class ListSecondSallestandlargNo {

	public static void main(String[] args) {
		 int n, temp;
	        Scanner s = new Scanner(System.in);
	        System.out.print("Enter no. of elements you want in array(Minimum 2):");
	        n = s.nextInt();
	        List<Integer> list =new  ArrayList<Integer>();
	        System.out.println("Enter all the elements:");
	        for (int i = 0; i < n; i++) 
	        {
	        	list.add(s.nextInt());
	        }
	        
	       Collections.sort(list);
	       Iterator<Integer> it = list.iterator();
	        while(it.hasNext()) {
	        	System.out.print(" "+it.next());
	        }
	        System.out.println();
	        System.out.println("Second Largest:"+list.get(n-2));
	        System.out.println("Smallest:"+list.get(1));
	    }

	}



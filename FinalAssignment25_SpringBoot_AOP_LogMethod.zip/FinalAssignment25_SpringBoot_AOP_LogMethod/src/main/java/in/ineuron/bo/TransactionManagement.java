package in.ineuron.bo;

import org.aspectj.lang.JoinPoint;

import org.aspectj.lang.reflect.MethodSignature;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class TransactionManagement  {
    
    @Before("execution(* in.ineuron.service.MyService.*(..))")
    public void logMethodCall(JoinPoint joinPoint) {
        MethodSignature methodSignature = (MethodSignature) joinPoint.getSignature();
        String methodName = methodSignature.getName();
        Object[] args = joinPoint.getArgs();
        
        System.out.println("Calling method: " + methodName);
        
        for (int i = 0; i < args.length; i++) {
            System.out.println("Parameter " + (i + 1) + ": " + args[i]);
        }
    }
    
    @AfterReturning(pointcut = "execution(* in.ineuron.service.MyService.*(..))", returning = "result")
    public void logMethodReturn(JoinPoint joinPoint, Object result) {
        MethodSignature methodSignature = (MethodSignature) joinPoint.getSignature();
        String methodName = methodSignature.getName();
        
        System.out.println("Method " + methodName + " returned: " + result);
    }
}
package in.ineuron;

import org.springframework.boot.SpringApplication;

import org.springframework.boot.autoconfigure.SpringBootApplication;

import in.ineuron.service.MyService;

@SpringBootApplication
public class SptingBootAopLogMethodApplication {

	public static void main(String[] args) {
		SpringApplication.run(SptingBootAopLogMethodApplication.class, args);
		
		MyService myService = new MyService();
        myService.performOperation1("Hello Ineuron");
        myService.performOperation2(51, 100);
	}

}

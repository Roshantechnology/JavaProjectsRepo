package in.ineuron.service;

import org.springframework.stereotype.Service;

@Service
public class MyService {
    
    public void performOperation1(String parameter) {
        System.out.println("Performing operation 1 with parameter: " + parameter);
    }
    
    public int performOperation2(int a, int b) {
        int result = a + b;
        System.out.println("Performing operation 2 with parameters: " + a + ", " + b);
        System.out.println("Result: " + result);
        return result;
    }
}
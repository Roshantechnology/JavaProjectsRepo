package in.ineuron.model;

import javax.persistence.Entity;
import javax.persistence.Id;

import org.hibernate.annotations.DynamicInsert;

@Entity
@DynamicInsert(value=true)
public class employees {
	@Id
	private Integer Eid;
	private String Ename;
	private String Eaddress;
	private Integer Esalary;
	
	public employees() {
		
	}
	
	public Integer getEid() {
		return Eid;
	}
	public void setEid(Integer eid) {
		Eid = eid;
	}
	public String getEname() {
		return Ename;
	}
	public void setEname(String ename) {
		Ename = ename;
	}
	public String getEaddress() {
		return Eaddress;
	}
	public void setEaddress(String eaddress) {
		Eaddress = eaddress;
	}
	public Integer getEsalary() {
		return Esalary;
	}
	public void setEsalary(Integer esalary) {
		Esalary = esalary;
	}
	@Override
	public String toString() {
		return "Employee [Eid=" + Eid + ", Ename=" + Ename + ", Eaddress=" + Eaddress + ", Esalary=" + Esalary + "]";
	}
	
	
}

package in.ineuron.test;


import org.hibernate.HibernateException;

import org.hibernate.Session;

import in.ineuron.model.employees;
import in.ineuron.util.HibernateUtil;

public class GetRecordApp {

	public static void main(String[] args) throws Exception {

		Session session = null;
		int Eid = 1;
		try {
			session = HibernateUtil.getSession();

			if (session != null) {
				employees employee=session.get(employees.class, Eid);
				if (employee != null)
					System.out.println(employee);
				else
					System.out.println("Record not found for the given id :: "+Eid);
			}
		} catch (HibernateException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			HibernateUtil.closeSession(session);
			HibernateUtil.closeSessionFactory();
		}

	}

}
